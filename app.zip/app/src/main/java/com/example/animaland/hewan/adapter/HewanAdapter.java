package com.example.animaland.hewan.adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.animaland.hewan.R;
import com.example.animaland.hewan.entity.Hewan;

import java.util.List;

public class HewanAdapter extends BaseAdapter {

    private Context mContext;
    private LayoutInflater layoutInflater;
    private List<Hewan> hewanList;

    public HewanAdapter(Context context, List<Hewan> hewanList) {
        this.hewanList = hewanList;
        this.mContext = context;
        this.layoutInflater = LayoutInflater.from(mContext);

    }

    @Override
    public int getCount() {
        return hewanList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        ViewHolder holder;
        if (view == null) {
            view = layoutInflater.inflate(R.layout.activity_item_list_hewan, parent, false);
            holder = new ViewHolder();
            view.setTag(holder);


            holder.textViewNama = (TextView) view.findViewById(R.id.textViewNamaHewan);
            holder.textViewId = (TextView) view.findViewById(R.id.textViewId);
        } else holder = (ViewHolder) view.getTag();

        holder.textViewNama.setText(hewanList.get(position).getNama());
        holder.textViewId.setText(hewanList.get(position).get_id() + "");

        return view;
    }

    class ViewHolder {
        private TextView textViewNama, textViewId;
    }
}
