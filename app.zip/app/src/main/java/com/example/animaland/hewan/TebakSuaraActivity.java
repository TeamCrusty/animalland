package com.example.animaland.hewan;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.animaland.hewan.util.KlikSuara;

import java.util.Random;

public class TebakSuaraActivity extends Activity implements View.OnClickListener {

    private MediaPlayer mediaPlayer = null;
    private MediaPlayer mediaPlayer2 = null;
    private TextView textViewPertanyaan;
    private Button buttonA, buttonB, buttonC;
    private String jawabBenar;
    private KlikSuara suara;

    public static int randInt(int min, int max) {
        Random rand = new Random();

        int randomNum = min + (int) (Math.random() * ((max - min) + 1));

        return randomNum;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tebak_suara);

        startComp();

        Typeface font = Typeface.createFromAsset(getAssets(), "Days.otf");
        buttonA.setTypeface(font);
        buttonB.setTypeface(font);
        buttonC.setTypeface(font);
        textViewPertanyaan.setTypeface(font);


        suara = new KlikSuara(this);

        setData();


        buttonA.setOnClickListener(this);
        buttonB.setOnClickListener(this);
        buttonC.setOnClickListener(this);

    }

    void startComp() {
        textViewPertanyaan = (TextView) findViewById(R.id.textViewPertanyaanSuara);
        buttonA = (Button) findViewById(R.id.buttonASuara);
        buttonB = (Button) findViewById(R.id.buttonBSuara);
        buttonC = (Button) findViewById(R.id.buttonCSuara);
    }

    @Override
    protected void onPause() {
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying())
                mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
            finish();
        }

        if (mediaPlayer2 != null && mediaPlayer2.isPlaying()) {
            mediaPlayer2.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
        super.onPause();

    }

    @Override
    protected void onStop() {
        super.onStop();

        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
        }

        if (mediaPlayer2 != null && mediaPlayer2.isPlaying()) {
            mediaPlayer2.stop();
            mediaPlayer2.release();
        }
    }

    void setData() {



        int randInt = randInt(0, 5);

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {

                try {
                    Thread.sleep(8000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
        });
        thread.start();
    }

    void jawabBenar(String jawab) {
        Intent intent;
        if (jawab.equalsIgnoreCase(jawabBenar)) {
            Log.i("jawab", jawab);
            Log.i("Jawab benar", jawabBenar);
            intent = new Intent(TebakSuaraActivity.this, HasilActivity.class);
            intent.putExtra("kuis", "suara");
            intent.putExtra("jawab", "benar");
            mediaPlayer2.stop();
            finish();
            startActivity(intent);
        } else {
            intent = new Intent(TebakSuaraActivity.this, HasilActivity.class);
            intent.putExtra("kuis", "suara");
            intent.putExtra("jawab", "salah");
            mediaPlayer2.stop();
            finish();
            startActivity(intent);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.buttonASuara:
                suara.klik();
                jawabBenar(buttonA.getText().toString());
                break;
            case R.id.buttonBSuara:
                suara.klik();
                jawabBenar(buttonB.getText().toString());
                break;
            case R.id.buttonCSuara:
                suara.klik();
                jawabBenar(buttonC.getText().toString());
                break;
            default:
                break;
        }
    }

    @Override
    public void onBackPressed() {
        if (mediaPlayer != null && mediaPlayer.isPlaying())
            mediaPlayer.stop();
        if (mediaPlayer2 != null && mediaPlayer2.isPlaying()) {
            mediaPlayer2.stop();
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (mediaPlayer != null && mediaPlayer.isPlaying())
            mediaPlayer.stop();

        if (mediaPlayer2 != null && mediaPlayer2.isPlaying()) {
            mediaPlayer2.stop();
        }
        super.onDestroy();
    }
}
