package com.example.animaland.hewan;

import android.app.ListActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;


public class HighScoreActivity extends ListActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_score);

        String kuis = getIntent().getExtras().getString("kuis");

        Log.i("kuis", kuis + "");


    }
}
