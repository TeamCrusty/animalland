package com.example.animaland.hewan;

import android.app.Activity;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;



public class HewanDetailActivity extends Activity {

    TextView textViewPenjelasan;
    ImageView imageViewSuara, imageViewSuaraPenjelasan;
    MediaPlayer mediaPlayer;

    String suara, namaHewan;
    int resIdSuaraHewan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_hewan_detail);

        onCreatedComp();

        int id = getIntent().getExtras().getInt("id");

        Typeface font = Typeface.createFromAsset(getAssets(), "Action_Man.ttf");
        textViewPenjelasan.setTypeface(font);


        imageViewSuara.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mediaPlayer = MediaPlayer.create(getApplicationContext(), resIdSuaraHewan);
                mediaPlayer.start();
            }
        });


        final int reIdSuaraPenjelasan = getResources().getIdentifier("d_"+suara, "raw", getPackageName());
        imageViewSuaraPenjelasan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer = MediaPlayer.create(getApplicationContext(), reIdSuaraPenjelasan);
                mediaPlayer.start();
            }
        });

    }

    void onCreatedComp() {
        imageViewSuara = (ImageView) findViewById(R.id.imageButtonSuara);
        textViewPenjelasan = (TextView) findViewById(R.id.textViewPenjelasanDetail);
        imageViewSuaraPenjelasan = (ImageView) findViewById(R.id.imageButtonSuaraPenjelasan);

    }


    @Override
    protected void onPause() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
        }
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
        }
        super.onBackPressed();
    }
}
