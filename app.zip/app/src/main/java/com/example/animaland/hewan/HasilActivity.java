package com.example.animaland.hewan;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.example.animaland.hewan.util.KlikSuara;
import com.example.animaland.hewan.util.TempScore;


public class HasilActivity extends Activity implements View.OnClickListener {

    private Button buttonMainLagi, buttonScore;
    private TextView textViewJawab, textViewScore;
    private String kuis;
    private KlikSuara suara;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_hasil);

        suara = new KlikSuara(this);


        startCom();


        Typeface font = Typeface.createFromAsset(getAssets(), "Days.otf");
        textViewJawab.setTypeface(font);
        textViewScore.setTypeface(font);
        buttonScore.setTypeface(font);
        buttonMainLagi.setTypeface(font);

        String jawab = getIntent().getExtras().getString("jawab");
        kuis = getIntent().getExtras().getString("kuis");


        if (jawab.equals("benar") && kuis.equals("gambar")) {
            textViewJawab.setText("Jawaban Benar");

            TempScore.addScoreGambar();

            textViewScore.setText(TempScore.getScore_gambar() + "");
        } else if (jawab.equals("benar") && kuis.equals("suara")) {
            textViewJawab.setText("Jawaban Benar");
            TempScore.addScoreSuara();

            textViewScore.setText(TempScore.getScore_suara() + "");
        } else {
            textViewScore.setText("0");

            textViewJawab.setText("Jawaban Salah");


        }

        buttonMainLagi.setOnClickListener(this);
        buttonScore.setOnClickListener(this);
    }

    void startCom() {
        buttonMainLagi = (Button) findViewById(R.id.buttonMainLagi);
        buttonScore = (Button) findViewById(R.id.buttonScore);
        textViewJawab = (TextView) findViewById(R.id.textViewJawaban);
        textViewScore = (TextView) findViewById(R.id.textViewScore);
    }

    @Override
    public void onClick(View v) {
        Intent intent;
        switch (v.getId()) {
            case R.id.buttonMainLagi:
                suara.klik();

                if (kuis.equals("gambar")) {
                    intent = new Intent(HasilActivity.this, TebakGambarActivity.class);
                    finish();
                    startActivity(intent);
                } else {
                    intent = new Intent(HasilActivity.this, TebakSuaraActivity.class);
                    finish();
                    startActivity(intent);
                }
                break;
            case R.id.buttonScore:
                suara.klik();

                TempScore.removeScoreGambar();
                TempScore.removeScoreSuara();

                intent = new Intent(HasilActivity.this, HighScoreActivity.class);
                intent.putExtra("kuis", kuis);
                finish();
                startActivity(intent);
            default:
                break;
        }
    }
}
