package com.example.animaland.hewan.entity;

public class UserName {

    static String Username;

    public static String getUsername() {
        return Username;
    }

    public static void setUsername(String username) {
        Username = username;
    }
}
