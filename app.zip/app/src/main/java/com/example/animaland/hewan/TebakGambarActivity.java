package com.example.animaland.hewan;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.example.animaland.hewan.util.KlikSuara;

import java.util.Random;

public class TebakGambarActivity extends Activity implements View.OnClickListener {

    private TextView textViewPertanyaan;
    private Button buttonA, buttonB, buttonC;


    private String jawabBenar;
    private KlikSuara suara;


    public static int randInt(int min, int max) {
        Random rand = new Random();

        int randomNum = min + (int) (Math.random() * ((max - min) + 1));

        return randomNum;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_tebak_gambar);

        onStartComp();



        Typeface typeface = Typeface.createFromAsset(getAssets(), "Days.otf");
        textViewPertanyaan.setTypeface(typeface);
        buttonA.setTypeface(typeface);
        buttonB.setTypeface(typeface);
        buttonC.setTypeface(typeface);


        buttonA.setOnClickListener(this);
        buttonB.setOnClickListener(this);
        buttonC.setOnClickListener(this);
    }

    void onStartComp() {
        textViewPertanyaan = (TextView) findViewById(R.id.textViewPertanyaan);
        buttonA = (Button) findViewById(R.id.buttonJawabA);
        buttonB = (Button) findViewById(R.id.buttonJawabB);
        buttonC = (Button) findViewById(R.id.buttonJawabC);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.buttonJawabA:
                suara.klik();
                jawabBenar(buttonA.getText().toString());
                break;
            case R.id.buttonJawabB:
                suara.klik();
                jawabBenar(buttonB.getText().toString());
                break;
            case R.id.buttonJawabC:
                suara.klik();
                jawabBenar(buttonC.getText().toString());
                break;
            default:
                break;
        }
    }

    void jawabBenar(String jawab) {
        Intent intent;
        if (jawab.equals(jawabBenar)) {
            intent = new Intent(TebakGambarActivity.this, HasilActivity.class);
            intent.putExtra("kuis", "gambar");
            intent.putExtra("jawab", "benar");
            finish();
            startActivity(intent);
        } else {
            intent = new Intent(TebakGambarActivity.this, HasilActivity.class);
            intent.putExtra("kuis", "gambar");
            intent.putExtra("jawab", "salah");
            startActivity(intent);

        }
    }



}
